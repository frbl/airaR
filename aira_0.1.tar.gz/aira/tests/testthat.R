library('testthat')
set.seed(1234)
test_check('aira')
